export { default } from "./Text";
