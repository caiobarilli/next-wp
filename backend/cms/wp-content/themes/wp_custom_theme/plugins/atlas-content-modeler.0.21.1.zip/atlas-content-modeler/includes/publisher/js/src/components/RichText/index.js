export { default } from "./RichText";
